const successMessage = document.getElementById('success');
const form =
    document.getElementById('info-form');

form.addEventListener('submit', (event) => {
    event.preventDefault();
    successMessage.classList.remove('cover');
});